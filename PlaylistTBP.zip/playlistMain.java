package playlistApp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

public class playlistMain {

	private static ArrayList<Album> albums = new ArrayList<Album>();

	public static void main(String[] args) {
		Album album = new Album("Meteora", "Linkin Park");
		album.addSong("Numb", 3.46);
		album.addSong("Crawling", 3.55);
		album.addSong("Don't stay", 4.14);
		album.addSong("In the End", 3.18);
		album.addSong("Hit hte floor", 3.33);
		album.addSong("Easier to run", 3.15);
		album.addSong("Lying away", 2.58);
		album.addSong("One step closer", 3.16);
		album.addSong("Papercut", 3.45);
		albums.add(album);

		album = new Album("For those about to rock", "AC/DC");
		album.addSong("For those about to rock", 5.44);
		album.addSong("I put finger on you", 3.25);
		album.addSong("Lets go", 3.45);
		album.addSong("C.O.D.", 5.25);
		album.addSong("Evil Walks", 3.33);
		albums.add(album);

		LinkedList<Song> playList = new LinkedList<Song>();
		albums.get(0).addToPlayList("Lying away", playList);// Doesnt exist
		albums.get(0).addToPlayList("Don't stay", playList);
		albums.get(1).addToPlayList(4, playList);
		albums.get(0).addToPlayList(0, playList);
		albums.get(0).addToPlayList(1, playList);
		albums.get(0).addToPlayList(2, playList);
		albums.get(0).addToPlayList(3, playList);
		play(playList);
	}

	private static void play(LinkedList<Song> playList) {
		Scanner input = new Scanner(System.in);
		boolean quit = false;
		boolean forward = true;
		ListIterator<Song> listIterator = playList.listIterator();
		if (playList.size() == 0) {
			System.out.println("No ongs to play ");
			return;
		} else {
			System.out.println("Now playing " + listIterator.next().toString());
			printMenu();
		}
		while (!quit) {
			int action = input.nextInt();
			input.nextLine();
			switch (action) {
			case 0:
				System.out.println("Playlist complete ");
				quit = true;

				break;
			case 1:
				if (!forward) {
					if (listIterator.hasNext()) {
						listIterator.next();
					}
					forward = true;
				}
				if (listIterator.hasNext()) {
					System.out.println("Now playing " + listIterator.next().toString());
				} else {
					System.out.println("We have reached the end of the playlist");
					forward = false;
				}
				break;
			case 2:
				if (forward) {
					if (listIterator.hasPrevious()) {
						listIterator.previous();
					}
					forward = false;
				}
				if (listIterator.hasPrevious()) {
					System.out.println("Now playing " + listIterator.previous().toString());

				} else {
					System.out.println("We are at the start of the playlist");
					forward = true;
				}
				break;
			case 3:
				if (forward) {
					if (listIterator.hasPrevious()) {
						System.out.println("Playing previous " + listIterator.previous().toString());
						forward = false;
					} else {
						System.out.println("We are at the start of the list");
					}

				} else {
					if (listIterator.hasNext()) {
						System.out.println("Now replaying " + listIterator.next().toString());
					} else {
						System.out.println("We have reached the end of the list ");
					}
				}
				break;
			case 4:
				printList(playList);
				break;
			case 5:
				printMenu();
				break;

			}
		}
	}

	private static void printMenu() {
		System.out.println("Available actions:\n press");
		System.out.println("0 to quit\n" + "1 - to play next song\n" + "2 - to play previous song\n"
				+ "3 - to replay the current song\n" + "4 - list songs in playlist\n"
				+ "5 - print available actions\n");
	}

	private static void printList(LinkedList<Song> playList) {
		Iterator<Song> iterator = playList.iterator();
		System.out.println("========================");

		while (iterator.hasNext()) {
			System.out.println(iterator.hasNext());
		}
		System.out.println("========================");

	}

}
